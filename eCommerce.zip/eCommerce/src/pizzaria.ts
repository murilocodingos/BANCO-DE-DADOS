import fastify from "fastify";
import { knex } from './database'

const app = fastify()

//GET, DELETE, PUT, PUSH e PATCH

app.get('/pizzas', async ()=>{

    const pizzas = await knex('pizzas').insert({
        id_pedido: crypto.randomUUID(),
        nome: 'Pizza do Tonhão',
        categoria: 'Pizza',
        preco: 65
    }).returning('*')

    await knex('sobremesas').insert({
        id_pedido: crypto.randomUUID(),
        nome: 'Pizza de Bengala Doce',
        categoria: 'Sobremesas',
        preco: 30
    }).returning('*')

    return pizzas

})

app.listen({port:3055}).then(() =>{
    console.log("Tonhão Pizzaria está aberta")
})