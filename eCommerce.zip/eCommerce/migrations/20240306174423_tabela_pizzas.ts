import type { Knex } from "knex";

export async function up(knex: Knex): Promise<void> {
    await knex.schema.createTable('pizzas', (table) => {
        table.uuid('id_pedido').primary(); // uuid (Identificador único universal)
        table.text('nome').notNullable();
        table.text('categoria').notNullable();
        table.decimal('preco', 10, 2).notNullable();
        table.timestamp('created').defaultTo(knex.fn.now()).notNullable(); // essa coluna terá incrementada automaticamente a data em que foi executada alterações na tabela
    });

    await knex.schema.createTable('sobremesas', (table) => {
        table.uuid('id_pedido').primary(); // uuid (Identificador único universal)
        table.text('nome').notNullable();
        table.text('categoria').notNullable();
        table.decimal('preco', 10, 2).notNullable();
        table.timestamp('created').defaultTo(knex.fn.now()).notNullable();
    });
}

export async function down(knex: Knex): Promise<void> {
    await knex.schema.dropTableIfExists('pizzas');
    await knex.schema.dropTableIfExists('sobremesas');
}
